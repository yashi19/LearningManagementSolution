
export interface TeacherModel {
  id?:number;  
  name: string;
}

