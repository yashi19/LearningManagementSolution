export interface BatchModel {
   id?:number;
   name: string; 
 
}

