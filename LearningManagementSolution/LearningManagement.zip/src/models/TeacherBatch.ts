
export interface TeacherBatchModel {
    id?:number;  
    teacherId:number;
    batchId:number;
  }
  
  