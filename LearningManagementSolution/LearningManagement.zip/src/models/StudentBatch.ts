export interface StudentBatchModel {
    id?:number;  
    studentId:number;
    batchId:number;
  }

  