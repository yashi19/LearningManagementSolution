
export interface StudentModel {
  id?:number;  
  name: string;
}

