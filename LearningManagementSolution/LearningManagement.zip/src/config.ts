export const DB = {
    DATABASE: "learning_management",
    USERNAME: "ngrusr",
    PASSWORD: "ngrpass"
  };
  
export const SERVER_PORT = process.env.PORT || 8000;
    