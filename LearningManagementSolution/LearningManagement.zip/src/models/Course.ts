export interface CourseModel {
  id?:number;  
  name: string;
}

