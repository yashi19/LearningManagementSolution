
export interface SubjectModel {
  id?:number;  
  name: string;
}

